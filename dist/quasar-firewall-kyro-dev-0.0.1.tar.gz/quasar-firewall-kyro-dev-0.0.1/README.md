# AI Firewall
An AI powered firewall designed to detect mallicious HTTP requests and decide weather to process them or not.