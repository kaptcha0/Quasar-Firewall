echo "Initializeing proxy server with paramaters $0 and $1"
python main.py -s $0 $1